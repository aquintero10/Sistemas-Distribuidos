<?php
$host="localhost";
$user="root";
$password="";
$db="crud1";
$con = new mysqli($host,$user,$password,$db);

?>